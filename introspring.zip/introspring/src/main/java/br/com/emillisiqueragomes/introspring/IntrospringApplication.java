package br.com.emillisiqueiragomes.introspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntrospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntrospringApplication.class, args);
	}

}
